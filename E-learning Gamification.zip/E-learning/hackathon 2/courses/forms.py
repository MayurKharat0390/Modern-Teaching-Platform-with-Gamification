from django import forms
from .models import Course, Video

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['title', 'description', 'thumbnail', 'price', 'is_published']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }

class VideoForm(forms.ModelForm):
    class Meta:
        model = Video
        fields = ['title', 'video_file', 'description', 'order']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        } 