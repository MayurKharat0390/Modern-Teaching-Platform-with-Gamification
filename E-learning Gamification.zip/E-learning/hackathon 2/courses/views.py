from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.db.models import Q
from .models import Course, Video
from accounts.models import User
from .forms import CourseForm, VideoForm
from django.db.models import Sum
from .models import StudentXP, CourseCompletion
                                                                                                       
def home(request):
    courses = Course.objects.all()[:6]  # Show latest 6 courses
    return render(request, 'courses/home.html', {'courses': courses})

@login_required
def course_create(request):
    if not request.user.is_teacher:
        messages.error(request, "Only teachers can create courses.")
        return redirect('home')
    
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.teacher = request.user
            course.save()
            messages.success(request, 'Course created successfully!')
            return redirect('course_detail', pk=course.pk)
    else:
        form = CourseForm()
    return render(request, 'courses/course_form.html', {'form': form})

@login_required
def course_edit(request, pk):
    course = get_object_or_404(Course, pk=pk)
    
    # Check if the user is the course teacher
    if request.user != course.teacher:
        messages.error(request, "You don't have permission to edit this course.")
        return redirect('course_detail', pk=pk)
    
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES, instance=course)
        if form.is_valid():
            form.save()
            messages.success(request, 'Course updated successfully!')
            return redirect('course_detail', pk=course.pk)
    else:
        form = CourseForm(instance=course)
    
    return render(request, 'courses/course_form.html', {
        'form': form,
        'course': course,
        'is_edit': True
    })

@login_required
def video_upload(request, course_pk):
    course = get_object_or_404(Course, pk=course_pk)
    if request.user != course.teacher:
        messages.error(request, "You don't have permission to add videos to this course.")
        return redirect('course_detail', pk=course_pk)
    
    if request.method == 'POST':
        form = VideoForm(request.POST, request.FILES)
        if form.is_valid():
            video = form.save(commit=False)
            video.course = course
            video.save()
            messages.success(request, 'Video uploaded successfully!')
            return redirect('course_detail', pk=course_pk)
    else:
        form = VideoForm()
    return render(request, 'courses/video_form.html', {'form': form, 'course': course})

def course_detail(request, pk):
    course = get_object_or_404(Course, pk=pk)
    videos = course.videos.all().order_by('order')
    return render(request, 'courses/course_detail.html', {
        'course': course,
        'videos': videos
    })

@login_required
def course_enroll(request, pk):
    if not request.user.is_student:
        messages.error(request, "Only students can enroll in courses.")
        return redirect('course_detail', pk=pk)
    
    course = get_object_or_404(Course, pk=pk)
    
    # Prevent teachers from enrolling in their own courses
    if request.user == course.teacher:
        messages.error(request, "Teachers cannot enroll in their own courses.")
        return redirect('course_detail', pk=pk)
    
    if request.user in course.students.all():
        messages.info(request, "You are already enrolled in this course.")
    else:
        course.students.add(request.user)
        messages.success(request, f"You have successfully enrolled in {course.title}!")
    return redirect('course_detail', pk=pk)

def search_courses(request):
    query = request.GET.get('q', '')
    courses = Course.objects.filter(
        Q(title__icontains=query) |
        Q(description__icontains=query)
    )
    return render(request, 'courses/search_results.html', {
        'courses': courses,
        'query': query
    })

def search_teachers(request):
    query = request.GET.get('q', '')
    teachers = User.objects.filter(
        is_teacher=True
    ).filter(
        Q(username__icontains=query) |
        Q(first_name__icontains=query) |
        Q(last_name__icontains=query)
    )
    return render(request, 'courses/teacher_search.html', {
        'teachers': teachers,
        'query': query
    })

@login_required
def course_delete(request, pk):
    course = get_object_or_404(Course, pk=pk)
    
    # Check if the user is the course teacher
    if request.user != course.teacher:
        messages.error(request, "You don't have permission to delete this course.")
        return redirect('course_detail', pk=pk)
    
    if request.method == 'POST':
        course_title = course.title
        # Delete the course
        course.delete()
        messages.success(request, f'Course "{course_title}" has been deleted successfully.')
        return redirect('teacher_profile')
    
    return redirect('course_detail', pk=pk)

@login_required
def video_player(request, course_pk, video_pk):
    video = get_object_or_404(Video, pk=video_pk, course_id=course_pk)
    course = video.course
    
    # Check if user has access to the video
    if request.user != course.teacher and request.user not in course.students.all():
        messages.error(request, "You don't have permission to view this video.")
        return redirect('course_detail', pk=course_pk)
    
    # Get user's progress data
    completed_videos = []
    total_xp = 0
    is_course_completed = False
    if request.user in course.students.all():
        completed_videos = StudentXP.objects.filter(
            student=request.user,
            course=course,
            video__isnull=False
        ).values_list('video_id', flat=True)
        total_xp = StudentXP.objects.filter(
            student=request.user,
            course=course
        ).aggregate(Sum('xp_points'))['xp_points__sum'] or 0
        is_course_completed = CourseCompletion.objects.filter(
            student=request.user,
            course=course
        ).exists()
    
    return render(request, 'courses/video_player.html', {
        'video': video,
        'course': course,
        'completed_videos': completed_videos,
        'total_xp': total_xp,
        'total_videos': course.videos.count(),
        'is_course_completed': is_course_completed
    })

def teacher_profile(request, teacher_id):
    teacher = get_object_or_404(User, id=teacher_id, is_teacher=True)
    courses = Course.objects.filter(teacher=teacher).order_by('-created_at')
    total_students = sum(course.students.count() for course in courses)
    total_videos = sum(course.videos.count() for course in courses)
    
    return render(request, 'courses/teacher_profile.html', {
        'teacher': teacher,
        'courses': courses,
        'total_students': total_students,
        'total_videos': total_videos,
    })

def teacher_courses(request, teacher_id):
    teacher = get_object_or_404(User, id=teacher_id, is_teacher=True)
    courses = Course.objects.filter(teacher=teacher).order_by('-created_at')
    return render(request, 'courses/teacher_courses.html', {
        'teacher': teacher,
        'courses': courses
    })

@login_required
def enrolled_students(request, course_pk):
    course = get_object_or_404(Course, pk=course_pk)
    
    # Check if the user is the course teacher
    if request.user != course.teacher:
        messages.error(request, "You don't have permission to view enrolled students.")
        return redirect('course_detail', pk=course_pk)
    
    students = course.students.all()
    student_progress = []
    
    for student in students:
        completed_videos = Video.objects.filter(
            course=course,
            id__in=StudentXP.objects.filter(
                student=student,
                course=course,
                video__isnull=False
            ).values_list('video_id', flat=True)
        ).count()
        total_videos = course.videos.count()
        progress = (completed_videos / total_videos * 100) if total_videos > 0 else 0
        
        student_progress.append({
            'student': student,
            'progress': progress,
            'completed_videos': completed_videos,
            'total_videos': total_videos,
            'xp_points': StudentXP.objects.filter(student=student, course=course).aggregate(Sum('xp_points'))['xp_points__sum'] or 0
        })
    
    return render(request, 'courses/enrolled_students.html', {
        'course': course,
        'student_progress': student_progress
    })

@login_required
def video_completion(request, course_pk, video_pk):
    video = get_object_or_404(Video, pk=video_pk, course_id=course_pk)
    course = video.course
    
    # Check if user is enrolled in the course
    if request.user not in course.students.all():
        messages.error(request, "You must be enrolled in the course to mark videos as complete.")
        return redirect('course_detail', pk=course_pk)
    
    # Check if video is already completed
    if StudentXP.objects.filter(student=request.user, course=course, video=video).exists():
        messages.info(request, "You have already completed this video.")
        return redirect('video_player', course_pk=course_pk, video_pk=video_pk)
    
    # Award XP points for video completion
    StudentXP.objects.create(
        student=request.user,
        course=course,
        video=video,
        xp_points=10,  # 10 XP points for completing a video
        description=f"Completed video: {video.title}"
    )
    
    # Check if all videos are completed
    total_videos = course.videos.count()
    completed_videos = StudentXP.objects.filter(
        student=request.user,
        course=course,
        video__isnull=False
    ).count()
    
    if completed_videos == total_videos:
        # Award bonus XP for course completion
        StudentXP.objects.create(
            student=request.user,
            course=course,
            xp_points=50,  # 50 bonus XP points for completing the course
            description=f"Completed course: {course.title}"
        )
        
        # Create course completion record
        CourseCompletion.objects.create(
            student=request.user,
            course=course
        )
        
        messages.success(request, f"Congratulations! You have completed the course '{course.title}'!")
    else:
        messages.success(request, f"You have completed the video '{video.title}'!")
    
    return redirect('video_player', course_pk=course_pk, video_pk=video_pk)

@login_required
def course_certificate(request, course_pk):
    course = get_object_or_404(Course, pk=course_pk)
    completion = get_object_or_404(CourseCompletion, student=request.user, course=course)
    
    if not completion.certificate_issued:
        # Generate certificate (you'll need to implement this)
        # For now, we'll just mark it as issued
        completion.certificate_issued = True
        completion.save()
    
    if completion.certificate_file:
        return redirect(completion.certificate_file.url)
    else:
        messages.error(request, "Certificate not available yet.")
        return redirect('course_detail', pk=course_pk)
