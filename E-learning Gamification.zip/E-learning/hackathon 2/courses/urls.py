from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.course_create, name='course_create'),
    path('<int:pk>/', views.course_detail, name='course_detail'),
    path('<int:pk>/edit/', views.course_edit, name='course_edit'),
    path('<int:pk>/delete/', views.course_delete, name='course_delete'),
    path('<int:course_pk>/upload-video/', views.video_upload, name='video_upload'),
    path('<int:course_pk>/video/<int:video_pk>/', views.video_player, name='video_player'),
    path('<int:pk>/enroll/', views.course_enroll, name='course_enroll'),
    path('search/', views.search_courses, name='search_courses'),
    path('teachers/search/', views.search_teachers, name='search_teachers'),
    path('teachers/<int:teacher_id>/', views.teacher_profile, name='teacher_profile'),
    path('teachers/<int:teacher_id>/courses/', views.teacher_courses, name='teacher_courses'),
    path('<int:course_pk>/students/', views.enrolled_students, name='enrolled_students'),
    path('<int:course_pk>/video/<int:video_pk>/complete/', views.video_completion, name='video_completion'),
    path('<int:course_pk>/certificate/', views.course_certificate, name='course_certificate'),
] 