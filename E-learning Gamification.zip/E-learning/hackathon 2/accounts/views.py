from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.views.generic import CreateView
from django.contrib import messages
from .models import User, StudentProfile, TeacherProfile
from courses.models import CourseCompletion, Course, StudentXP
from .forms import StudentSignUpForm, TeacherSignUpForm
from django.db.models import Sum

# Create your views here.

class StudentSignUpView(CreateView):
    model = User
    form_class = StudentSignUpForm
    template_name = 'registration/signup_form.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'student'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        return redirect('student_profile')

class TeacherSignUpView(CreateView):
    model = User
    form_class = TeacherSignUpForm
    template_name = 'registration/signup_form.html'

    def get_context_data(self, **kwargs):
        kwargs['user_type'] = 'teacher'
        return super().get_context_data(**kwargs)

    def form_valid(self, form):
        user = form.save()
        login(self.request, user)
        return redirect('teacher_profile')

@login_required
def student_profile(request):
    if not request.user.is_student:
        return redirect('home')
    profile = StudentProfile.objects.get(user=request.user)
    enrolled_courses = request.user.courses_enrolled.all()
    completed_courses = CourseCompletion.objects.filter(student=request.user).select_related('course')
    total_videos_watched = sum(completion.course.videos.count() for completion in completed_courses)
    
    return render(request, 'accounts/student_profile.html', {
        'profile': profile,
        'enrolled_courses': enrolled_courses,
        'completed_courses': [completion.course for completion in completed_courses],
        'total_videos_watched': total_videos_watched
    })

@login_required
def teacher_profile(request):
    if not request.user.is_teacher:
        return redirect('home')
    profile = TeacherProfile.objects.get(user=request.user)
    courses = request.user.courses_taught.all()
    return render(request, 'accounts/teacher_profile.html', {
        'profile': profile,
        'courses': courses
    })

@login_required
def profile_edit(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        user.email = request.POST.get('email')
        user.save()
        
        if user.is_student:
            profile = StudentProfile.objects.get(user=user)
        else:
            profile = TeacherProfile.objects.get(user=user)
            
        if 'profile_picture' in request.FILES:
            profile.profile_picture = request.FILES['profile_picture']
            profile.save()
            
        messages.success(request, 'Your profile has been updated successfully.')
        return redirect('student_profile' if user.is_student else 'teacher_profile')
        
    return render(request, 'accounts/profile_edit.html')

@login_required
def custom_logout(request):
    logout(request)
    messages.success(request, 'You have been successfully logged out.')
    return redirect('home')

@login_required
def student_profile_view(request, student_id):
    student = get_object_or_404(User, id=student_id, is_student=True)
    profile = StudentProfile.objects.get(user=student)
    
    # Get enrolled courses
    enrolled_courses = student.courses_enrolled.all()
    
    # Get completed courses
    completed_courses = CourseCompletion.objects.filter(student=student).select_related('course')
    total_videos_watched = sum(completion.course.videos.count() for completion in completed_courses)
    
    return render(request, 'accounts/student_profile.html', {
        'profile': profile,
        'enrolled_courses': enrolled_courses,
        'completed_courses': [completion.course for completion in completed_courses],
        'total_videos_watched': total_videos_watched,
        'is_own_profile': False
    })
