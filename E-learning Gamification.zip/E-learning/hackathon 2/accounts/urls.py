from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('signup/student/', views.StudentSignUpView.as_view(), name='student_signup'),
    path('signup/teacher/', views.TeacherSignUpView.as_view(), name='teacher_signup'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', views.custom_logout, name='logout'),
    path('profile/student/', views.student_profile, name='student_profile'),
    path('profile/student/<int:student_id>/', views.student_profile_view, name='student_profile_view'),
    path('profile/teacher/', views.teacher_profile, name='teacher_profile'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
] 