from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from .models import User, StudentProfile, TeacherProfile

class StudentSignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_student = True
        user.email = self.cleaned_data.get('email')
        user.save()
        student_profile = StudentProfile.objects.create(user=user)
        return user

class TeacherSignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)
    expertise = forms.CharField(required=True)
    years_of_experience = forms.IntegerField(required=True)
    
    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_teacher = True
        user.email = self.cleaned_data.get('email')
        user.save()
        teacher_profile = TeacherProfile.objects.create(
            user=user,
            expertise=self.cleaned_data.get('expertise'),
            years_of_experience=self.cleaned_data.get('years_of_experience')
        )
        return user 